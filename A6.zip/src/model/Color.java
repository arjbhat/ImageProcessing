package model;

/**
 * The color interface that is used to represent colors that are on the observable color spectrum.
 * The red, green, and blue components, as well as the intensity, luma, and value can be observed.
 */
public interface Color {
  /**
   * Get the red component of this color.
   *
   * @return the red channel of the color
   */
  int getRed();

  /**
   * Get the green component of this color.
   *
   * @return the green channel of the color
   */
  int getGreen();

  /**
   * Get the blue component of this color.
   *
   * @return the blue channel of the color
   */
  int getBlue();

  /**
   * Get the alpha value of this color.
   *
   * @return the alpha value of the color
   */
  int getAlpha();

  /**
   * Get the largest component of this color.
   *
   * @return the largest channel of the color
   */
  int getValue();

  /**
   * Get the intensity of this color (average of the components).
   *
   * @return the intensity of the color
   */
  int getIntensity();

  /**
   * Get the weighted sum of the color using the RGB channels.
   *
   * @return the luminescence of the color
   */
  int getLuma();

  /**
   * Two RGBColors are equal if they have the same values for the red, green, and blue channels,
   * and are equally transparent.
   *
   * @param other the object that we are comparing this color to
   * @return true if the two colors are the same or false otherwise
   */
  boolean equals(Object other);

  /**
   * A hash that represents a specific color.
   *
   * @return a hash for that color
   */
  int hashCode();
}
